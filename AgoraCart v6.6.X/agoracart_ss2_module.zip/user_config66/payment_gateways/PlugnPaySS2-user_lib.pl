$PnPSS2_pt_gateway_account = '';
$PnPSS2_pt_order_classifier = "Online Order";
$PnPSS2_verify_message = "Please verify the information below.  When you are confident it is correct, click on the \'Submit Order For Processing\' button to go to the PlugnPay.com site where you will enter your payment information.";
$PnPSS2_display_checkout_tos = "yes";
$PnPSS2_tos_display_address = qq|Company Name<br>123 Main St.<br>Townsville, NY 12345<br>123-456-7890|;
$PnPSS2_pb_post_auth = 'yes';
$PnPSS2_email_template = "emailPlate_text_default01.inc";
$PnPSS2_admin_email_template = "admin_emailPlate_text_default01.inc";
$PnPSS2_verifytable = "verifyTable_standard.inc";
$PnPSS2_thankstable = "thanksTable_basic1.inc";
$PnPSS2_top_message = "top of order form";
$PnPSS2_special_message = "Special Instructions Message";
$PnPSS2_show_table = "yes";
#
1;
